import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Goghlines extends PApplet {

/**
<p>Based on an early version of Koenie's fieldlines code.</p>
<ul>
 <li><b>0-9</b> for different presets</li>
 <li><b>d</b> toggles doubled colors</li>
 <li><b>i</b> inverts coloration</li>
 <li><b>m</b> uses modified line drawing algorithm</li>
 <li><b>s</b> spins the electrodes in 3d</li>
</ul>
<p>Colors stolen from <a href="http://en.wikipedia.org/wiki/Cafe_Terrace_at_Night">The Cafe Terrace on the Place du Forum</a>, with van Gogh's first starry sky.</p>
*/
//import processing.opengl.*;

float var = HALF_PI/3;
float minl = 1; // min length of particle steps
float maxl = 30; // max length of particle steps
float maxsteps = 20; // average max steps a particle takes (must be > nparticles)
float framesPerFlip = 100;
int nelectrodes = 5;
int nparticles = 2400;
int pathWidth = 4; // particle path stroke weight
int framesPerRefresh = 1;
float border = 30; // particle origin boundaries
float rotY, rotZ;

//color[] pal = {#FF0000, #00FF00, #0000FF}; // rgb (debugging)
int[] pal = {0xff5782A3,0xffDEB21D,0xff27201E,0xffA64B0E}; // patio

float colorScale = pal.length / TWO_PI;
float off = 0;
float cutoff; // too close to an electrode
int particlesPerFrame;

Electrode[] e;
Particle[] p;

public void setup() {
  size(640,360,P2D);
  off = random(random(pal.length));
  background(getColor(off));
  colorMode(RGB);
  strokeWeight(pathWidth);
  shuffle(pal);
  
  e = new Electrode[nelectrodes];
  for (int i = 0; i < e.length; i++)
    e[i] = new Electrode();
  p = new Particle[nparticles];
  for (int i = 0; i < p.length; i++) 
    p[i] = new Particle();
    
  particlesPerFrame = nparticles / framesPerRefresh;
  cutoff = 3 * pathWidth;
  rotY = random(0,0.015f);
  rotZ = random(0,0.015f);
}

int portion = 0;
public void draw() {
  translate(width/2, height/2);
  
  off = (off + random(.01f/(float) framesPerRefresh)) % pal.length;

  noFill();
  noStroke();
  
  portion = (portion + 1) % framesPerRefresh;
  
  for (int i = portion; i < particlesPerFrame; i++)
    if(p[i + portion * particlesPerFrame].update())
      p[i + portion * particlesPerFrame] = new Particle();
  for (int i = 0; i < p.length/maxsteps; i++)
    p[(int) random(p.length)] = new Particle();
  if(random(1) < 1/framesPerFlip)
    e[(int) random(e.length)].flip();
    
  if(rotElectrodes) {
    for (int i = 0; i < nelectrodes; i++) {
      e[i].rotateY(rotY);
      e[i].rotateZ(rotZ);
    }
  }
}
  
public void mousePressed() {
  setup();
}

boolean rotElectrodes;
boolean modLine = true;
boolean doubleColors;
boolean invertColoration = true;
public void keyPressed() {
  if(key == '1') preset(1, 6, 2400, 4, 20, 30, HALF_PI/3, true, false);
  if(key == '2') preset(2, 6, 10000, 3, 20, 30, HALF_PI/3, true, false);
  if(key == '3') preset(10, 6, 30000, 4, 20, 30, HALF_PI/3, true, false);
  if(key == '4') preset(10, 5, 30000, 1, 300, 30, HALF_PI/6, false, true);
  if(key == '5') preset(3, 4, 14000, 50, 200, 30, HALF_PI/3, false, false);
  if(key == '6') preset(3, 3, 12000, 50, 200, 30, HALF_PI/4, false, false);
  if(key == '7') preset(1, 4, 5500, 150, 100, 15, HALF_PI/6, false, false);
  if(key == '8') preset(1, 50, 1000, 4, 500, 15, HALF_PI/3, false, false);
  if(key == '9') preset(1, 100, 10000, 1, 500, 5, 0, true, false);
  if(key == '0') preset(1, 200, 200, 10, 500, 2, 0, true, false);
  if(key == 'd') doubleColors = doubleColors ? false : true;
  if(key == 'i') invertColoration = invertColoration ? false : true;
  if(key == 'm') modLine = modLine ? false : true;
  if(key == 's') rotElectrodes = rotElectrodes ? false : true;
}

public void preset(int fpr, int el, int pa, int pw, float ms, float ml, float v, boolean ic, boolean d) {
  framesPerRefresh = fpr;
  float scaling = (float) (width * height) / (740 * 480);
  nelectrodes = (int) constrain(el * scaling, 1, 999999);
  nparticles = (int) constrain(pa * scaling, 1, 999999);
  pathWidth = pw;
  maxsteps = ms;
  maxl = ml;
  var = v;
  invertColoration = ic;
  doubleColors = d;
  setup();
}
class Electrode {
  float x, y, z;
  boolean polarity;
  Electrode() {
    this(
      random(-width/2, width/2),
      random(-height/2, height/2),
      random(-height/2, height/2),
      (random(1) > .5f));
  }
  Electrode(float x, float y, float z, boolean polarity) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.polarity = polarity;
  }
  public void flip() {
    polarity = polarity ? false : true;
  }
  public void rotateY(float a) {
    float nx = cos(a) * x - sin(a) * z;
    z = sin(a) * x + cos(a) * z;
    x = nx;
  }
  public void rotateZ(float a) {
    float nx = cos(a) * x - sin(a) * y;
    y = sin(a) * x + cos(a) * y;
    x = nx;
  }
}
class Particle {
  float x, y, nx, ny, l, angle;
  Particle() {
    this(
      random(-width/2 - border, width/2 + border),
      random(-height/2 - border, height/2 + border));
  }
  Particle(float nx, float ny) {
    x = nx; 
    y = ny;
  }  
  public boolean update() {
    Vector total = new Vector(0, 0, 0, 0);
    // the contents of this loop happen 40,000 times a frame
    float a, dx, dy;
    for (int i = 0; i < e.length; i++) {
      a = e[i].polarity ? 
        atan2(y - e[i].y, x - e[i].x) : // attract
        atan2(e[i].y - y, e[i].x - x);  // repel
      dx = e[i].x - x;
      dy = e[i].y - y;
      float sqdist = dx * dx + dy * dy;
      if(sqdist < cutoff) return true;
      total.add(a, 1 / (sqdist + 0.00000001f));
    }
    angle = total.getAngle() + random(-var, var);
    l = random(minl, maxl);
    nx = x + l * cos(angle);
    ny = y + l * sin(angle);

    int cc = getColor(generalModulo(off + angle * colorScale * (doubleColors ? 2 : 1), pal.length));
    if(g.strokeWeight > 5 && modLine) {
      fill(cc, 80);
      modLine(x, y, nx, ny);
    } else {
      stroke(cc, 80);
      line(x, y, nx, ny);
    }

    x = nx;
    y = ny;
    
    return false;
  }
}
// not symmetric, but close enough
public void shuffle(int[] array) {
  for(int i = 0; i < array.length; i++) {
    int temp = array[i];
    int toSwitch = (int) random(array.length);
    array[i] = array[toSwitch];
    array[toSwitch] = temp;
  }
}

public int getColor(float pos) {
  int left = PApplet.parseInt(floor(pos)) % (pal.length);
  int right = PApplet.parseInt(ceil(pos)) % (pal.length);
  float amt = pos - left;
  if(invertColoration)
    amt = 1 - amt;    
  return lerpColor(pal[left], pal[right], amt);
}

public float generalModulo(float x, float y) {
  if(x < 0) x += y * ((int) (-x / y) + 1);
  return x % y;
}

public void modLine(float x1, float y1, float x2, float y2) {
  float halfWeight = g.strokeWeight * .5f;
  float ap = atan2(y2 - y1, x2 - x1) + HALF_PI;
  float xoff = halfWeight * cos(ap);
  float yoff = halfWeight * sin(ap);
  beginShape();
  vertex(x1 - xoff, y1 - yoff);
  vertex(x1 + xoff, y1 + yoff);
  vertex(x2 + xoff, y2 + yoff);
  vertex(x2 - xoff, y2 - yoff);
  endShape();
}
class Vector {
  float x, y, xc, yc;  
  Vector(float x, float y, float a, float d) {
    this.x = x;
    this.y = y;
    this.xc = d * cos(a);
    this.yc = d * sin(a);
  }
  public void add(float a, float d) {
    this.xc += d * cos(a);
    this.yc += d * sin(a);
  }
  public float getAngle() {
    return atan2(yc, xc);
  }
  public float getLength() {
    return sqrt(xc * xc + yc * yc);
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#d4d0c8", "Goghlines" });
  }
}
