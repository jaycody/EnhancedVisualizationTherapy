import processing.core.*; 
import processing.xml.*; 

import java.util.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class sketch_apr04a extends PApplet {


int N = 200;
float repulsion = 0.1f;        // how much the particles repel each other
float contraction = 0.0005f;   // how much they are pulled towards the center
float mainHue = random(360);  
float damping = 0.9f;          // how much drag is applied to the particles

// allows for fast adding and deleting of the particles
LinkedList<Particle> parts = new LinkedList<Particle>();

public void setup() {
  size(400,400);
  background(0);
  smooth();
  colorMode(HSB, 360, 1, 1);
}

public void draw() {
  if (mousePressed && mouseButton == LEFT){
    
    // create some new particles, adding the mouse velocity
    for (int i = 0; i < 5; i++) {
      parts.add(new Particle(mouseX+random(-0.7f,0.7f), mouseY+random(-0.7f,0.7f),
      (mouseX-pmouseX)*0.3f, (mouseY-pmouseY)*0.3f));
    }
  } else if (mousePressed && mouseButton == RIGHT) {
    
    //pick a new hue
    mainHue = random(360);
  }
  if (frameCount % 2 == 0){
      noStroke();
      fill(0,15);
      rect(0,0,width,height);
  }

  ListIterator<Particle> it = parts.listIterator();
  while(it.hasNext()){
    Particle p = it.next();
    if (!p.alive) {
      it.remove();
      continue;
    }
    p.vx += (width/2-p.x)*contraction;
    p.vy += (height/2-p.y)*contraction;
    
    // iterate over the particles which the current particle has not interacted with yet
    ListIterator<Particle> forward = parts.listIterator(it.nextIndex());
    while(forward.hasNext()){
      Particle np = forward.next();
      float p2npx = np.x-p.x;
      float p2npy = np.y-p.y;
      float sqdist = p2npx*p2npx + p2npy*p2npy;
      
      //apply repulsive forces
      p.vx -= p2npx/sqdist * repulsion/p.s;
      np.vx+= p2npx/sqdist * repulsion/np.s;
      p.vy -= p2npy/sqdist * repulsion/p.s;
      np.vy+= p2npy/sqdist * repulsion/np.s;
    }
    
    // apply a random force
    float nscale = 0.01f;
    float offset = 500;
    p.vx += (noise(p.x*nscale, p.y*nscale,frameCount*nscale) - 0.5f) / p.s;
    p.vy += (noise(p.x*nscale+offset, p.y*nscale+offset,frameCount*nscale*0.2f) - 0.5f) / p.s;
    p.update();
  }
  
  for (Particle p : parts){
    noStroke();    
    p.draw();
  }
}
class Particle {
  float x,y;
  float vx = 0, vy = 0;
  float s = 10;
  int age = 0;
  int maxAge = (int) random(100,600);
  boolean alive = true;
  float col = random(20,40) + mainHue;
  float relAge = 0;
  float speedSq = 0;
  
  Particle(float xx, float yy) {
    x = xx;
    y = yy;
  }
  
  Particle(float xx, float yy, float vxx, float vyy) {
    x = xx;
    y = yy;
    vx = vxx;
    vy = vyy;
  }
  
  public void update() {
    x += vx;
    y += vy;
    vx *= damping;
    vy *= damping;
    age++;
    relAge = ((float)age)/maxAge;
    speedSq = vx*vx + vy*vy;
    s = 10 * (1 - (relAge))*(1 - (relAge))*(1 - (relAge))+0.5f;
    if (age > maxAge)
      alive = false;
  }
  
  public void draw() {
    //fill(col,1-(10-s)*0.05,(10-s)/10+0.8);
    fill((int)(col + speedSq*10*relAge)%360,
              1 - relAge*0.3f,
              speedSq*relAge*2+0.2f,
              speedSq*relAge*255 + 255*relAge);
    ellipse(x,y,s,s);
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ECE9D8", "sketch_apr04a" });
  }
}
